package com.technlolab.utilisateurs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UtilisateursApplicationTests {

	@Test
	void contextLoads() {
	}

}
